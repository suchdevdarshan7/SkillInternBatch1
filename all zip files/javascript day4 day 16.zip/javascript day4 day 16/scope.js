
// & var let and const Scoping : 
// ! var
// var a = 10 ; 
// var name = "Darshan";
// console.log(name)
// console.log(a)
// window.console.log(("Hello world"))
// window.alert("Hello world")

// ! Accesblity of var -- Global scoping 

// ! Let and const :  --Script scope or local scope : 

// let a = 10 ; 
// const b = 20 ; 
// console.log(a)
// console.log(b)

// {
//     let a = 10 ;
// }
// console.log(a)

// {
//     const ab = 10 ; 
// }

// console.log(ab)


// a = 10 ;
// console.log(a)