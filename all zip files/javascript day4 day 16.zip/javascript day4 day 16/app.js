// ! 3 Keywords : var let const : 

// ? var keyword :

// var number; // Declaration: 
// number = 10 ; // Intialization:
// number = 20 ; // ReIntialization:

// var number = 5 ; // Redeclaration:

// var number2 = 1000; // Declaration and initialization in the same line 
// console.log(number)
// console.log(number2)

// console.log("hi")

//^ var keyword we can decalre , initialize , reinitialize , redeclare and declaration and initialization can be done in the same line 


// ? let Keyword  ==> Es6 feature

// let number ; //Declaration: 
// number = 10 ; // Intialization 

// let number = 20 ;//Uncaught SyntaxError: Identifier 'number' has already been declared

// let number2 = 20 ; // Declaration and initalization in the same line is possible
// console.log(number)

//^ let keyword we can decalre , initialize , reinitialize , cannot redeclare and declaration and initialization can be done in the same line 

// ? const keyword : ==> Es6 

// const number; // Declaration: Uncaught SyntaxError: Missing initializer in const declaration
// number = 10 ; // Initialization is not possible;

// const number = 10; //Declare and intialize in the sameline 

// number = 20; // We cannot modify the value 

// console.log(number)
// console.log("Const working")

//^ const keyword we cannot declare , initialize , reinitialize , cannot redeclare but we can do declaration and initialization can be done in the same line 







