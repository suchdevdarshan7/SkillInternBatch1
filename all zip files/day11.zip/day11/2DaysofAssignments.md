*** Project 1 ***

1. A portfolio --> use should all the property like transition, hover,
positioning !

2. Clone this website : https://bootstrapmade.com/demo/Plato/

3. Clone this website: https://bootstrapmade.com/demo/Squadfree/

4. Clone this website: https://html5up.net/hyperspace

Convert it to a zip folder :