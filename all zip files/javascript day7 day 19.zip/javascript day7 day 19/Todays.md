# Todays plan 

1. Explain the higher order and call back functions again 
2. splice, slice  , reverse , fill , at , includes and indexof()