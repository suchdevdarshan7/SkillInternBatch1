*** Topics Covered *** 

*** HTML *** 

1. How the web works
2. HTML CSS JS 
3. Heading tags
4. Paragraph tags
5. Anchor tags
6. List tags --> UL and OL 
7. Div tags --> 
8. span tags 
9. semantic tags --> section article
10. table 
11. input 
12. form 
13. Marquee tags 
14. videos and audio
15. image tags 
17. select and option tags
18. Br and hr
19. button 
20. label tags 
21. Emmet

22. Keyboard shortcuts to make html easier

Emmet CheatSheet : https://docs.emmet.io/cheat-sheet/:


