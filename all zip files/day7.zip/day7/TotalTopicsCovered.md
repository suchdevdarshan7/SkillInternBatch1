*** Topics Covered *** 

*** HTML *** 

1. How the web works
2. HTML CSS JS 
3. Heading tags
4. Paragraph tags
5. Anchor tags
6. List tags --> UL and OL 
7. Div tags --> 
8. span tags 
9. semantic tags --> section article
10. table 
11. input 
12. form 
13. Marquee tags 
14. videos and audio
15. image tags 
17. select and option tags
18. Br and hr
19. button 
20. label tags 
21. Emmet

22. Keyboard shortcuts to make html easier

Emmet CheatSheet : https://docs.emmet.io/cheat-sheet/:


*** CSS PART ONE *** 

1. INTRODUCTION 
2. TYPES OF CSS --> INTERNAL INLINE EXTERNAL 
3. ! IMPORTANT 
4. FONT AND BACKGROUND COLOR 
5. FONT PROPERTY 
6. BACKGROUND IMAGES
7. LINEAR AND RADIAL GRADIENT


*** CSS SECOND PART *** 

1. Selectors --> id , class , generic , attribute, attribute value, universal , tag 
2. Combinators --> descendant , general sibling , adjacent sibling , child 
3. Sizing units --> vh vw rem px % 


*** CSS THIRD PART ***
1.Display: block, inline
2.Box modal 


*** Fourth day ***


