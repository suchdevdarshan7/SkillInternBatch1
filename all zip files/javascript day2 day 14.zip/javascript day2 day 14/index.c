#include<stdio.h>

void sum(int a, int b)
{
    printf("%d and %d is %d", a, b, a + b);
}
int main(){
    

    return 0;
}