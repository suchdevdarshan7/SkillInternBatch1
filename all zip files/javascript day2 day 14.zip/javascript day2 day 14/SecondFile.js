//! Output methods: 

//? 1.Console.log() --> developers 
// console.log("Hello world");

//? 2. Document.write() --> UI
// document.write("Hello this is something") 

//? 3. Document.writeln() --> Ui
// document.writeln("Hello world this is document.writeln ")

// document.write("Hi")
// document.write("Hello")
// document.writeln("Hi")
// document.write("<br>")
// document.write("Hello")

// ? 4. alert() 

// alert("Hello welcome to my webpage")

//? 5. confirm()

// confirm("Are you above 18 because only 18 above people can vote:")

//! Input methods: 

//? 6. prompt ()

// let a = prompt("Enter your name : ")
// let age = prompt ('Enter your age : ')


// 7. find the sum : 

// let a = prompt("Enter first number")
// let b = prompt("Enter second number")
// console.log(`The typeof a is ${typeof a}`)
// console.log(`The typeof b is ${typeof b}`)
// let c = a + b; 

// console.log(c)

// let c = "darshan";
// console.log(c)
// c = 10 ; 
// console.log(c)


// Imperative: 

//! [1,4,9,16,25]; 
// let brr  =[];

// for(let i = 0 ; i<arr.length;i++){
    //     brr[i] = arr[i]**2;
    // }
    // console.log(brr)
    
// ! Declarative : 
    
// let arr = [1,2,3,4,5];
// let brr = arr.map((el)=> el**2);
// console.log(brr)




