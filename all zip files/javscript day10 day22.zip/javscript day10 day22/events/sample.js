button.addEventListener("click",function(){

})

function demo(){

}

button.addEventListener("click",demo);