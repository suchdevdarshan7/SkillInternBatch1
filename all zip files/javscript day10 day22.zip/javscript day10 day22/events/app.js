
const heading = document.querySelector('#heading');
const body = document.body;
function ChangeColor(){
    body.style.backgroundColor = "black";
    heading.style.color = "white";
}

function ChangeColor2(){
    body.style.backgroundColor = "orange";
    heading.style.color = "crimson";
}