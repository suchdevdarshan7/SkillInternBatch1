//! Boolean represent 2 thing 1 --> true, 2--> false

// console.log(typeof )

// var car = 'this is a car'
// var bike = null;
// console.log(typeof null)

// let bigNumber = 1n;

// console.log(typeof bigNumber)


// To see output in the console why? --> check whether our application is working well 

// console.log("Welcome to programming");

//! Arrays: 
// var Colors = ['Red', "Green","Blue","Yellow","Pink"];

// console.log(Colors)
// console.log(typeof Colors)

//! Objects: 

// var EmployeeData = {

//     ename: "Sachin Tendulkar",
//     eCompany:"BCCI",
//     eJob: "Batsmen",
// }

// console.log(EmployeeData)

//Date Object 

// let todayDate = new Date()

// console.log(todayDate)

// console.log(todayDate.getDate())
// console.log(todayDate.getMonth())
// console.log(todayDate.getTime())


// let a = 25;

// console.log(Math.sqrt(a))

// ! Sets:

let a  = new Set({value:10,value2:20, value3: 30});

console.log(typeof a)


