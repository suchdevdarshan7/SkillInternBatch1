1. Primitive  Data type:
    1. Number 
    2. String 
    3. Boolean 
    4. undefined 
    5. null 
    6. Symbols
    7. BigInt

2. Non primitive

    1. Arrays
    2. Objects
    3. Sets 
    4. Maps 
    5. Date()
    6. Math object

    

