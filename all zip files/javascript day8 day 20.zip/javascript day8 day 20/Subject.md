
methods :
lastIndexOf()
find()
findIndex()
sort()
foreach()
map() --> very important 
filter() --> very important
flat()
flatMap()
reduce()

# Research ! 

findLast()
some()
every()


// & ##-------------------- Homework --------------------
// & ## what will happen if i sort strings ! 
