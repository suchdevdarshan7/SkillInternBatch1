function App() {
  const a = 10;
  
  
  return (
    <div>
    <div className="container">Hello</div>
    <div className="box">World</div>
    
    </div>
  )
}

export default App
